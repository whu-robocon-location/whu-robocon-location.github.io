#ifndef _TIME2_H
#define _TIME2_H

#include "stm32f4xx.h"
#include "filter.h"


void time2_config(void);
#endif



