#ifndef _MYMATH_H
#define _MYMATH_H

#include <math.h>

#define PI ((float)3.141592654)

int fsign(float a);

#endif
