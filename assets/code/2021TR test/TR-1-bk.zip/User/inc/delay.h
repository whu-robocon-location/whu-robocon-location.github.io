#ifndef _DELAY_H
#define _DELAY_H

#include "stm32f4xx.h"

void delay_us(uint32_t us);
void delay_ms(u16 nms);

#endif
